<?
     session_start();
     $_SESSION['started'] = false;
     session_write_close();
?>
